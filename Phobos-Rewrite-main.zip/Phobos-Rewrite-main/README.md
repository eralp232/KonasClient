# konas

Gl dont care big coder

# Backup link

https://anonfiles.com/1focBdSbu9/konas_rar
