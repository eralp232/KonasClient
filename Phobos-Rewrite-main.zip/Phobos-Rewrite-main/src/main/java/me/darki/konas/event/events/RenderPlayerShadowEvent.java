package me.darki.konas.event.events;

public class RenderPlayerShadowEvent extends CancellableEvent {
}
