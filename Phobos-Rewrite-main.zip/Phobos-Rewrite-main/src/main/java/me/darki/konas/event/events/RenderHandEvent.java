package me.darki.konas.event.events;

public class RenderHandEvent extends CancellableEvent {
}
