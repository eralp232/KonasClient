package me.darki.konas.event.events;

public class PlayerPushedByWaterEvent extends CancellableEvent {
}
