package me.darki.konas.event.events;

public class RenderSignEvent extends CancellableEvent {}
