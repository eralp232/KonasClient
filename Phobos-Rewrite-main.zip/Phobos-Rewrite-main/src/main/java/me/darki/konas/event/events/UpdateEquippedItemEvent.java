package me.darki.konas.event.events;

public class UpdateEquippedItemEvent extends CancellableEvent {
}
