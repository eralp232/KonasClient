package me.darki.konas.event.events;

public class GuiRenderEvent {
}
