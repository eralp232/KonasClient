package me.darki.konas.event.events;

public class ZoomEvent {

    public static class Pre extends ZoomEvent {

    }

    public static class Post extends ZoomEvent {

    }
}
