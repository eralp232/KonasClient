#!/usr/bin/env bash

if [ -z "$1" ]; then
  /c/Program\ Files\ \(x86\)/Minecraft\ Launcher/MinecraftLauncher.exe
else
  "$1"
fi
